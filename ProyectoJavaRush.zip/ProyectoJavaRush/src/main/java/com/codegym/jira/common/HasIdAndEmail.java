package com.codegym.jira.common;

public interface HasIdAndEmail extends HasId {
    String getEmail();
}