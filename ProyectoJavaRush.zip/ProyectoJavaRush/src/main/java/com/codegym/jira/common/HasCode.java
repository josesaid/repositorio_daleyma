package com.codegym.jira.common;

public interface HasCode extends HasId {
    String getCode();
}