package com.codegym.jira;

import org.junit.jupiter.api.Test;

class CodegymJiraApplicationTests extends BaseTests {
    @Test
    void contextLoads() {
    }
}
