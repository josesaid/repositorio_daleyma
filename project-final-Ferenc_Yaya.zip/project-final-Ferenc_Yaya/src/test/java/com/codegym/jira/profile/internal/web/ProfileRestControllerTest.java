package com.codegym.jira.profile.internal.web;

import com.codegym.jira.login.AuthUser;
import com.codegym.jira.login.User;
import com.codegym.jira.profile.ProfileTo;
import com.codegym.jira.profile.internal.ProfileMapper;
import com.codegym.jira.profile.internal.ProfileRepository;
import com.codegym.jira.profile.internal.model.Profile;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.Collections;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProfileRestControllerTest {

    private static final long USER_ID = 1L;

    @Mock
    private ProfileMapper profileMapper;

    @Mock
    private ProfileRepository profileRepository;

    @Mock
    private User user;

    @InjectMocks
    private ProfileRestController profileRestController;

    private AuthUser createAuthUser() {
        when(user.id()).thenReturn(USER_ID);
        when(user.getEmail()).thenReturn("test@example.com");
        when(user.getPassword()).thenReturn("password");
        when(user.getRoles()).thenReturn(Collections.emptySet());
        return new AuthUser(user);
    }

    @Test
    void get_Success() {
        AuthUser authUser = createAuthUser();
        Profile profile = new Profile();
        ProfileTo profileTo = new ProfileTo(USER_ID, Set.of(), Set.of());

        when(profileRepository.getOrCreate(USER_ID)).thenReturn(profile);
        when(profileMapper.toTo(profile)).thenReturn(profileTo);

        ProfileTo result = profileRestController.get(authUser);

        assertEquals(USER_ID, result.getId());
    }

    @Test
    void get_Failure() {
        AuthUser authUser = createAuthUser();
        when(profileRepository.getOrCreate(USER_ID)).thenThrow(new RuntimeException());

        assertThrows(RuntimeException.class, () -> profileRestController.get(authUser));
    }

    @Test
    void update_Success() {
        AuthUser authUser = createAuthUser();
        ProfileTo profileTo = new ProfileTo(USER_ID, Set.of(), Set.of());
        Profile profile = new Profile();

        when(profileRepository.getOrCreate(USER_ID)).thenReturn(profile);
        when(profileMapper.updateFromTo(profile, profileTo)).thenReturn(profile);
        when(profileRepository.save(profile)).thenReturn(profile);

        assertDoesNotThrow(() -> profileRestController.update(profileTo, authUser));
    }

    @Test
    void update_Failure() {
        AuthUser authUser = createAuthUser();
        ProfileTo profileTo = new ProfileTo(USER_ID, Set.of(), Set.of());
        when(profileRepository.getOrCreate(USER_ID)).thenThrow(new RuntimeException());

        assertThrows(RuntimeException.class, () -> profileRestController.update(profileTo, authUser));
    }
}