package com.codegym.jira.common.internal.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.InitializingBean; // Agregar este import

import java.nio.charset.StandardCharsets;

@Component
@Profile("test-h2")
public class H2DataLoader implements InitializingBean {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private ResourceLoader resourceLoader;

    @Override
    public void afterPropertiesSet() throws Exception {
        try {
            Resource resource = resourceLoader.getResource("classpath:data-h2.sql");
            String sql = new String(resource.getInputStream().readAllBytes(), StandardCharsets.UTF_8);

            String[] statements = sql.split(";");

            for (String statement : statements) {
                String trimmed = statement.trim();
                if (!trimmed.isEmpty() && !trimmed.startsWith("--")) {
                    jdbcTemplate.execute(trimmed);
                }
            }

            System.out.println("Datos cargados exitosamente desde data-h2.sql");

        } catch (Exception e) {
            System.err.println("Error cargando datos: " + e.getMessage());
            e.printStackTrace();
        }
    }
}