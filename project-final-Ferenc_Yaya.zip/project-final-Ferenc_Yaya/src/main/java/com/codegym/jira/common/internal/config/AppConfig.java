package com.codegym.jira.common.internal.config;

import com.codegym.jira.common.util.JsonUtil;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.hibernate5.jakarta.Hibernate5JakartaModule;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;
import org.springframework.http.ProblemDetail;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.boot.jdbc.DataSourceBuilder;
import javax.sql.DataSource;

import java.util.Map;
import java.util.concurrent.Executor;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;
import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.NONE;

@Configuration
@Slf4j
@EnableCaching
@RequiredArgsConstructor
@EnableScheduling
public class AppConfig {

    private final AppProperties appProperties;
    private final Environment env;

    @Bean("mailExecutor")
    Executor getAsyncExecutor() {
        return new ThreadPoolTaskExecutor() {
            {
                setCorePoolSize(appProperties.getMailSendingProps().corePoolSize);
                setMaxPoolSize(appProperties.getMailSendingProps().maxPoolSize);
                setThreadNamePrefix("mail-");
            }
        };
    }

    @Bean("prodDataSource")
    @Profile({"prod", "dev"})
    public DataSource prodDataSource() {
        log.info("Configurando DataSource para perfil PRODUCCION/DESARROLLO con PostgreSQL");
        return DataSourceBuilder.create()
                .driverClassName("org.postgresql.Driver")
                .url(env.getProperty("spring.datasource.url"))
                .username(env.getProperty("spring.datasource.username"))
                .password(env.getProperty("spring.datasource.password"))
                .build();
    }

    @Bean("testH2DataSource")
    @Profile("test-h2")
    public DataSource testH2DataSource() {
        log.info("Configurando DataSource para perfil TEST con H2");
        return DataSourceBuilder.create()
                .driverClassName("org.h2.Driver")
                .url(env.getProperty("spring.datasource.url"))
                .username(env.getProperty("spring.datasource.username"))
                .password(env.getProperty("spring.datasource.password"))
                .build();
    }

    @Bean("testPostgresDataSource")
    @Profile("test-postgres")
    public DataSource testPostgresDataSource() {
        log.info("Configurando DataSource para perfil TEST con POSTGRES");
        return DataSourceBuilder.create()
                .driverClassName("org.postgresql.Driver")
                .url(env.getProperty("spring.datasource.url"))
                .username(env.getProperty("spring.datasource.username"))
                .password(env.getProperty("spring.datasource.password"))
                .build();
    }

    public boolean isProd() {
        return env.acceptsProfiles(Profiles.of("prod"));
    }

    public boolean isDev() {
        return env.acceptsProfiles(Profiles.of("dev"));
    }

    public boolean isTestPostgres() {
        return env.acceptsProfiles(Profiles.of("test-postgres"));
    }

    public boolean isTestH2() {
        return env.acceptsProfiles(Profiles.of("test-h2"));
    }

    public boolean isTest() {
        return env.acceptsProfiles(Profiles.of("test-postgres", "test-h2"));
    }

    @Autowired
    void configureAndStoreObjectMapper(ObjectMapper objectMapper) {
        objectMapper.registerModule(new Hibernate5JakartaModule());
        // https://stackoverflow.com/questions/7421474/548473
        objectMapper.addMixIn(ProblemDetail.class, MixIn.class);
        JsonUtil.setMapper(objectMapper);
    }

    //    https://stackoverflow.com/a/74630129/548473
    @JsonAutoDetect(fieldVisibility = NONE, getterVisibility = ANY)
    interface MixIn {
        @JsonAnyGetter
        Map<String, Object> getProperties();
    }
}
