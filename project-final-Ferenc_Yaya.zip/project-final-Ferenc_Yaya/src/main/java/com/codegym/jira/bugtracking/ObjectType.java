package com.codegym.jira.bugtracking;

public enum ObjectType {
    PROJECT,
    SPRINT,
    TASK
}
